import numpy as np


def F(x):
    # x = [x1, x2]
    x1 = 0  # fixme
    x2 = 0  # fixme

    # F(x) = [F_1(x), F_2(x)]
    F1 = 0  # fixme
    F2 = 0  # fixme

    return np.array([F1, F2])


def DF(x):
    x1 = 0  # fixme
    x2 = 0  # fixme

    # DF(x) is the Jacobian of F at x
    # DF(x)_{i,j} = djFi
    d1F1 = 1  # fixme
    d2F1 = 0  # fixme
    d1F2 = 1  # fixme
    d2F2 = 0  # fixme

    return np.array([[d1F1, d2F1], [d1F2, d2F2]])


# initialize with x = [1, 1]
x = np.array([0, 0])  # fixme
print(0, x)

# compute x_{n+1} = x_n - DF(x_n)^{-1}F(x_n)
for n in range(1, 8):
    Fx = F(x)
    DF_inverse = np.linalg.inv(DF(x))
    x = 0  # fixme
    print(n, x)
