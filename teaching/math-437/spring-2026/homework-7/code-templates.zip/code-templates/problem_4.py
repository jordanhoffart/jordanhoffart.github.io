import numpy as np

print("4a")

# create a random M x N matrix
# see np.random.rand()
M = 1  # fixme
N = 1  # fixme
A = 0  # fixme

# call the SVD algorithm on A
# see np.linalg.svd; use full_matrices=False
U, S, Vt = 0  # fixme

# check if the SVD holds
print("A = USVt ?", np.allclose(A, U * S @ Vt))

# extract the largest 2 singular values from S
s_1 = 0  # fixme
s_2 = 0  # fixme

print("s_1 =", s_1)
print("s_2 =", s_2)

# extract the column of U corresponding to the largest singular value
u_1 = 0  # fixme

print()

print("4b")

# Compute the error Err and the normalized error E
Err = 0
denominator = 0
for j in range(N):
    # jth column of A
    a_j = 0  # fixme

    # add to Err; see np.linalg.norm and np.dot
    Err += 0  # fixme

    # add to denominator; see np.linalg.norm
    denominator += 1  # fixme

# normalize Err
E = Err / denominator

print("Err =", Err)
print("E =", E)

print()

print("4c")

# construct a random unit vector of length M; see np.random.rand and
# np.linalg.norm
u = 0  # fixme
u = u / 1  # fixme

# compute the projection of u using the columns of A
proj = 0
for j in range(N):
    # jth column of A
    a_j = 0  # fixme

    # add to projection; see np.linalg.norm and np.dot
    proj += 0  # fixme

# The projection should be larger than Err
print("projection =", proj)
print("projection >= Err ?", proj > Err)
