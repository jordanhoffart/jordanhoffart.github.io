import numpy as np


def g(x):
    # x = [x1, x2]
    x1 = 0  # fixme
    x2 = 0  # fixme
    return 0  # fixme


def dg(x):
    # x = [x1, x2]
    x1 = 0  # fixme
    x2 = 0  # fixme

    # dg(x)_i = dig(x)
    d1g = 0  # fixme
    d2g = 0  # fixme

    return np.array([d1g, d2g])


# initialize with x_n = x0 = [1,1]
x0 = np.array([0, 0])  # fixme
print(0, x0)

for n in range(1, 3):
    # find 3 points (a0, h0), (a1, h1), (a2, h2) that define a quadratic
    # polynomial p(a) with p(ai) = hi = h(ai) that interpolates the function
    # h(a) = g(x0 - a * dg(x0) / norm(dg(x0)))
    #
    # take a0 = 0, find a2 such that h(a2) <= h(a0), and take
    # a1 = (a0 + a2) / 2

    a0 = 0
    h0 = 0  # fixme

    # gradient direction dg(x0) / norm(dg(x0))
    d0 = 0  # fixme

    # start with a2 = 1 and divide by 2 until h(a2) <= g(x0)
    a2 = 0  # fixme
    h2 = 0  # fixme
    while False:  # fixme
        a2 /= 1  # fixme
        h2 = 0  # fixme

    # compute a1 = (a0 + a2) / 2 and h1
    a1 = 0  # fixme
    h1 = 0  # fixme

    # while one could use the method of divided differences to express the
    # polynomial p(a) in a computationally efficient basis, we will be lazy and
    # represent p in the monomial basis
    #
    # p(a) = c0 + c1 * a + c2 * a**2
    #
    # Then, to find the coefficients c_0, c_1, c_2, we use the fact that
    # p(ai) = hi to set up the following Vandermonde system of equations:
    #
    # [1 a0 a0**2] [c0]   [h0]
    # [1 a1 a1**2] [c1] = [h1]
    # [1 a2 a2**2] [c2]   [h2]
    #
    # and solve for the coefficients. In this representation, the polynomial is
    # minimized at the critical value where p'(a) = 0, i.e.
    #
    # a_min = -c1 / (2 * c2)
    #

    vandermonde_matrix = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]])  # fixme
    h_vector = np.array([1, 1, 1])  # fixme
    coefficient_vector = np.linalg.solve(vandermonde_matrix, h_vector)
    a_min = 0  # fixme

    # x_{n+1}
    x1 = 0  # fixme
    print(n, x1)

    # prepare for next iteration
    x0 = 0  # fixme
