import numpy as np

print("4a")

M = 80
N = 20

A = np.random.rand(M, N)

U, S, Vt = np.linalg.svd(A, full_matrices=False)

u_1 = U[:, 0]
s_1 = S[0]
s_2 = S[1]

print("s_1 =", s_1)
print("s_2 =", s_2)
print("A = USVt ?", np.allclose(A, U * S @ Vt))

print()

print("4b")

Err = 0
denominator = 0
for j in range(N):
    a_j = A[:, j]
    Err += np.linalg.norm(a_j - np.dot(a_j, u_1) * u_1) ** 2
    denominator += np.linalg.norm(a_j) ** 2
E = Err / denominator

print("Err =", Err)
print("E =", E)

print()

print("4c")

u = np.random.rand(M)
u = u / np.linalg.norm(u)

proj = 0
for j in range(N):
    a_j = A[:, j]
    proj += np.linalg.norm(a_j - np.dot(a_j, u) * u) ** 2

print("projection =", proj)
print("projection >= Err ?", proj > Err)
