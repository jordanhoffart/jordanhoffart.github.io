import numpy as np


def g(x):
    return (x[0] + x[1] - 4) ** 2 + (x[0] ** 2 + x[1] ** 2 - 8) ** 2


def dg(x):
    return np.array(
        [
            2 * (x[0] + x[1] - 4) + 2 * (x[0] ** 2 + x[1] ** 2 - 8) * 2 * x[0],
            2 * (x[0] + x[1] - 4) + 2 * (x[0] ** 2 + x[1] ** 2 - 8) * 2 * x[1],
        ]
    )


x0 = np.array([1, 1])
print(0, x0)

for n in range(1, 3):
    a0 = 0
    a2 = 1

    h0 = g(x0)
    d0 = dg(x0) / np.linalg.norm(dg(x0))
    h2 = g(x0 - a2 * d0)

    while h2 > h0:
        a2 /= 2
        h2 = g(x0 - a2 * d0)

    a1 = a2 / 2
    h1 = g(x0 - a1 * d0)

    vandermonde = np.array([[a0**2, a0, 1], [a1**2, a1, 1], [a2**2, a2, 1]])
    values = np.array([h0, h1, h2])
    coefficients = np.linalg.solve(vandermonde, values)
    minimizer = -coefficients[1] / (2 * coefficients[0])

    x1 = x0 - minimizer * d0
    print(n, x1)
    x0 = x1
