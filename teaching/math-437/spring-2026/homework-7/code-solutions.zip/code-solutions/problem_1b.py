import numpy as np


def F(x):
    return np.array([x[0] ** 2 - x[1] ** 2, x[0] ** 3 + x[1] ** 3 - 16])


def DF(x):
    return np.array([[2 * x[0], -2 * x[1]], [3 * x[0] ** 2, 3 * x[1] ** 2]])


x = np.array([1, 1])
print(0, x)
for n in range(1, 8):
    x = x - np.linalg.inv(DF(x)) @ F(x)
    print(n, x)
