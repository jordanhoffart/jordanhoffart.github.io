"""
Solve the stiff ODE

y'(t) = -20 * y(t) + 21 * exp(t)

on the interval 0 <= t <= 1 with initial condition y(0) = 2. Use the explicit
Euler and implicit Euler schemes for step sizes h = 0.1 and h = 0.01. Output
plots of the numerical solutions and the exact solution

y(t) = exp(t) + exp(-20 * t).

"""

from math import exp
import matplotlib.pyplot as plt

# exact solution
exact = lambda t: 0  # fixme

# step sizes
hs = [0, 0]  # fixme

for n, h in enumerate(hs):
    # discrete times
    ts = [0]

    # forward Euler solution at the discrete times
    ys_fe = [0]  # fixme

    # backward Euler solution at the discrete times
    ys_be = [0]  # fixme

    # exact solution at the discrete times
    ys_exact = [0]  # fixme

    while ts[-1] < 1:
        # get old values
        t_old = ts[-1]
        y_fe_old = ys_fe[-1]
        y_be_old = ys_be[-1]
        y_exact_old = ys_exact[-1]

        # update time
        t = 0  # fixme

        # update forward Euler
        y_fe = 0  # fixme

        # update backward Euler
        y_be = 0  # fixme

        # update exact solution
        y_exact = 0  # fixme

        # save new values
        ts.append(t_n)
        ys_fe.append(y_fe)
        ys_be.append(y_be)
        ys_exact.append(y_exact)

    # plot
    plt.plot(ts, ys_exact, label="exact")
    plt.plot(ts, ys_fe, label="explicit Euler")
    plt.plot(ts, ys_be, label="implicit Euler")
    plt.title("h = {:e}".format(h))
    plt.legend()
    plt.savefig("plot-{}.png".format(n))
    plt.clf()
