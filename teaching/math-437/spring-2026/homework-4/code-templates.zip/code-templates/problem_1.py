"""
Use the Adams-Bashforth 4-step method,

y_{n+4} = y_{n+3} + h * 55 / 24 * f(t_{n+3},y_{n+3})
                  - h * 59 / 24 * f(t_{n+2}, y_{n+2})
                  + h * 37 / 24 * f(t_{n+1}, y_{n+1})
                  - h * 9 / 24 * f(t_n, y_n),

to solve the ODE

y'(t) = f(t,y(t))

with

f(t,y) = t * exp(3 * t) - 2 * y

and initial conditions from the exact solution

y(t) = t / 5 * exp(3 * t) - 1 / 25 * exp(3 * t) + 1 / 25 * exp(-2 * t).

Run from time t = 0 to t = 1 with step size h = 0.2, and print t_n, y_n at each
timestep.
"""

from math import exp
import matplotlib.pyplot as plt

# exact solution
exact = lambda t: 0  # fixme

# right-hand side function
f = lambda t, y: 0  # fixme

# step size
h = 0  # fixme

# initial conditions
t_0 = 0  # fixme
t_1 = 0  # fixme
t_2 = 0  # fixme
t_3 = 0  # fixme

y_0 = 0  # fixme
y_1 = 0  # fixme
y_2 = 0  # fixme
y_3 = 0  # fixme

# output initial values
print("{:e}, {:e}".format(t_0, y_0))
print("{:e}, {:e}".format(t_1, y_1))
print("{:e}, {:e}".format(t_2, y_2))
print("{:e}, {:e}".format(t_3, y_3))

t_4 = 0
y_4 = 0
while t_4 < 1:
    # update t_4, y_4
    t_4 = 0  # fixme
    y_4 = 0  # fixme

    # output new values
    print("{:e}, {:e}".format(t_4, y_4))

    # prepare for the next timestep
    t_0 = 0  # fixme
    t_1 = 0  # fixme
    t_2 = 0  # fixme
    t_3 = 0  # fixme

    y_0 = 0  # fixme
    y_1 = 0  # fixme
    y_2 = 0  # fixme
    y_3 = 0  # fixme
