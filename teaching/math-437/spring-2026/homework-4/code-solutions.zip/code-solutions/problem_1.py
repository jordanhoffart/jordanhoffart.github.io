"""
Use the Adams-Bashforth 4-step method,

y_{n+4} = y_{n+3} + h * 55 / 24 * f(t_{n+3},y_{n+3})
                  - h * 59 / 24 * f(t_{n+2}, y_{n+2})
                  + h * 37 / 24 * f(t_{n+1}, y_{n+1})
                  - h * 9 / 24 * f(t_n, y_n),

to solve the ODE

y'(t) = f(t,y(t))

with

f(t,y) = t * exp(3 * t) - 2 * y

and initial conditions from the exact solution

y(t) = t / 5 * exp(3 * t) - 1 / 25 * exp(3 * t) + 1 / 25 * exp(-2 * t).

Run from time t = 0 to t = 1 with step size h = 0.2, and print t_n, y_n at each
timestep.
"""

from math import exp
import matplotlib.pyplot as plt

exact = lambda t: t / 5 * exp(3 * t) - 1 / 25 * exp(3 * t) + 1 / 25 * exp(-2 * t)

h = 0.2

t_0 = 0
t_1 = h
t_2 = 2 * h
t_3 = 3 * h
t_4 = 0

y_0 = exact(t_0)
y_1 = exact(t_1)
y_2 = exact(t_2)
y_3 = exact(t_3)
y_4 = 0

f = lambda t, y: t * exp(3 * t) - 2 * y

print("n, t_n, y_n")
print("0, {:e}, {:e}".format(t_0, y_0))
print("1, {:e}, {:e}".format(t_1, y_1))
print("2, {:e}, {:e}".format(t_2, y_2))
print("3, {:e}, {:e}".format(t_3, y_3))

n = 3
while t_4 < 1:
    n += 1
    t_4 = t_3 + h
    y_4 = (
        y_3
        + h * 55 / 24 * f(t_3, y_3)
        - h * 59 / 24 * f(t_2, y_2)
        + h * 37 / 24 * f(t_1, y_1)
        - h * 9 / 24 * f(t_0, y_0)
    )

    print("{}, {:e}, {:e}".format(n, t_4, y_4))

    t_0 = t_1
    t_1 = t_2
    t_2 = t_3
    t_3 = t_4

    y_0 = y_1
    y_1 = y_2
    y_2 = y_3
    y_3 = y_4
