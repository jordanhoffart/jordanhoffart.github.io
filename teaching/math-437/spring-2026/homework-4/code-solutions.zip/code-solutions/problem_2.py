import sympy as sp

t_n, t, h = sp.symbols("t_n t h")

t_np1 = t_n + h
t_nm1 = t_n - h

L_nm1 = (t - t_n) * (t - t_np1) / (t_nm1 - t_n) / (t_nm1 - t_np1)
L_n = (t - t_nm1) * (t - t_np1) / (t_n - t_nm1) / (t_n - t_np1)
L_np1 = (t - t_nm1) * (t - t_n) / (t_np1 - t_nm1) / (t_np1 - t_n)

I_nm1 = sp.integrate(L_nm1, (t, t_n, t_np1)).simplify()
I_n = sp.integrate(L_n, (t, t_n, t_np1)).simplify()
I_np1 = sp.integrate(L_np1, (t, t_n, t_np1)).simplify()

print(I_nm1, I_n, I_np1)
