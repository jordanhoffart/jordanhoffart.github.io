"""
Solve the stiff ODE

y'(t) = -20y(t) + 21 * exp(t)

on the interval 0 <= t <= 1 with initial condition y(0) = 2. Use the explicit
Euler and implicit Euler schemes for step sizes h = 0.1 and h = 0.01. Output
plots of the numerical solutions and the exact solution

y(t) = exp(t) + exp(-20 * t).

"""

from math import exp
import matplotlib.pyplot as plt

exact = lambda t: exp(t) + exp(-20 * t)

hs = [0.1, 0.01]

for n, h in enumerate(hs):
    ts = [0]
    ys_fe = [2]
    ys_be = [2]
    ys_exact = [2]

    while ts[-1] < 1:
        y_fe = ys_fe[-1] + h * (-20 * ys_fe[-1] + 21 * exp(ts[-1]))
        y_be = (ys_be[-1] + h * 21 * exp(ts[-1] + h)) / (1 + 20 * h)
        y_exact = exact(ts[-1] + h)

        ts.append(ts[-1] + h)
        ys_fe.append(y_fe)
        ys_be.append(y_be)
        ys_exact.append(y_exact)

    plt.plot(ts, ys_exact, label="exact")
    plt.plot(ts, ys_fe, label="explicit Euler")
    plt.plot(ts, ys_be, label="implicit Euler")
    plt.title("h = {:e}".format(h))
    plt.legend()
    plt.savefig("plot-{}.png".format(n))
    plt.clf()
