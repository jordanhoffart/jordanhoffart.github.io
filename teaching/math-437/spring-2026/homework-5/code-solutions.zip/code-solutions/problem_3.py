import sympy as sp

A = sp.Matrix(
    [
        [sp.Rational(4, 100), sp.Rational(1, 100), sp.Rational(-1, 100)],
        [sp.Rational(2, 10), sp.Rational(5, 10), sp.Rational(-2, 10)],
        [1, 2, 4],
    ]
)

print("A^{-1} =", A.inv())
print("A^{-1} = (1/87) *", 87 * A.inv())
print("K(A) =", sp.simplify(sp.Rational(2463, 87) * 7))
print("K(A) ~", 2463 / 87 * 7)
