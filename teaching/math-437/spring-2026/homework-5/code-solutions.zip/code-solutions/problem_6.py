import sympy as sp

A = sp.Matrix([[2, -1, 1], [3, 3, 9], [3, 3, 5]])
print(A.det())
