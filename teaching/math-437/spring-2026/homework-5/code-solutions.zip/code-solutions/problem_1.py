"""
Solve A @ x = b with

A = [7 -1  1  1]
    [3  9  9  1]
    [3  3 15  1]
    [3  3  5 14]

b = [1 1 1 1]^T

using (a) Jacobi, (b) Gauß–Seidel, and (c) successive over-relaxation (SOR)
with omega = 1.0911. Report the residuals and the number of iterations. Here,
we follow numpy notation, where @ denotes matrix-vector multiplication.

Iterative methods write A in the form A = E + B and solve

E @ x_{n+1} + B @ x_n = b

with initial guess x_0. Here, we take x_0 = 0.

First, we let D be the diagonal of A and L be the strictly lower-triangular
part of A. Then, for

(a) Jacobi,      E := D,
(b) Gauß–Seidel, E := D + L,
(c) SOR,         E := D / omega + L.

To test if an iterative method is converging, we use the residual

r_{n+1} = norm(A @ x_{n+1} - b),

where norm(v) := sqrt(sum_i |v_i|^2) is the l_2 norm, which is the default used
by numpy.

(d) Find the spectral radius of the iteration matrix T := E^{-1} @ B for each
of the previous methods. We do this by finding the magnitude of the largest
eigenvalue of T.
"""

import numpy as np

A = np.array([[7, -1, 1, 1], [3, 9, 9, 1], [3, 3, 15, 1], [3, 3, 5, 14]])
b = np.array([1, 1, 1, 1])
omega = 1.0911

D = np.diag(np.diag(A))
L = np.tril(A, k=-1)

E_jacobi = D
E_gs = D + L
E_sor = D / omega + L

B_jacobi = A - E_jacobi
B_gs = A - E_gs
B_sor = A - E_sor

x0_jacobi = np.array([0, 0, 0, 0])
x0_gs = np.array([0, 0, 0, 0])
x0_sor = np.array([0, 0, 0, 0])

tol = 1e-5

n_jacobi = 0
n_gs = 0
n_sor = 0

resid_jacobi = 10 * tol
resid_gs = 10 * tol
resid_sor = 10 * tol

print("(a) Jacobi")
while resid_jacobi > tol:
    n_jacobi += 1
    x_jacobi = np.linalg.solve(E_jacobi, b - B_jacobi @ x0_jacobi)
    resid_jacobi = np.linalg.norm(A @ x_jacobi - b)
    print("{:d} {:e}".format(n_jacobi, resid_jacobi))
    x0_jacobi = x_jacobi
print()

print("(b) Gauß–Seidel")
while resid_gs > tol:
    n_gs += 1
    x_gs = np.linalg.solve(E_gs, b - B_gs @ x0_gs)
    resid_gs = np.linalg.norm(A @ x_gs - b)
    print("{:d} {:e}".format(n_gs, resid_gs))
    x0_gs = x_gs
print()

print("(c) SOR")
while resid_sor > tol:
    n_sor += 1
    x_sor = np.linalg.solve(E_sor, b - B_sor @ x0_sor)
    resid_sor = np.linalg.norm(A @ x_sor - b)
    print("{:d} {:e}".format(n_sor, resid_sor))
    x0_sor = x_sor
print()

print("(d) Spectral radii")

T_jacobi = np.linalg.inv(E_jacobi) @ B_jacobi
T_gs = np.linalg.inv(E_gs) @ B_gs
T_sor = np.linalg.inv(E_sor) @ B_sor

eigenvalues_jacobi = np.linalg.eigvals(T_jacobi)
eigenvalues_gs = np.linalg.eigvals(T_gs)
eigenvalues_sor = np.linalg.eigvals(T_sor)

spectral_radius_jacobi = max([abs(lam) for lam in eigenvalues_jacobi])
spectral_radius_gs = max([abs(lam) for lam in eigenvalues_gs])
spectral_radius_sor = max([abs(lam) for lam in eigenvalues_sor])

print("Jacobi:      {:e}".format(spectral_radius_jacobi))
print("Gauß–Seidel: {:e}".format(spectral_radius_gs))
print("SOR:         {:e}".format(spectral_radius_sor))
