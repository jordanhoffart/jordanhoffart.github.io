"""
For n = 10, 20, 40, solve

A @ x = b,

where A is the n x n tridiagonal matrix with entries 2 on the diagonal and -1
on the off-diagonals, and b is the n-dimensional vector with first and last
entry 1 and all other entries 0.

Use the Gauß–Seidel iterative method

(D + L) @ x_{n+1} + U @ x_n = b,

where D is the diagonal of A, L is the strictly lower-triangular part of A, and
U is the strictly upper-triangular part of A. Using the notation from class,

E := D + L,
B := A - E = U,
E @ x_{n+1} + B @ x_n = b.

Start with initial guess x_0 = 0, solve to tolerance 10^{-5}, and report the
number of iterations and the final residual. To compute the final residual,

r_{n+1} = norm(A @ x_{n+1} - b),

where norm() is the l_2 norm, which is the default used by numpy, and x_{n+1}
is the solution at the last iteration.
"""

import numpy as np

ns = [10, 20, 40]
tol = 1e-5

print("n iters resid")
for n in ns:
    off_diagonal = np.ones(n - 1)
    main_diagonal = -2 * np.ones(n)

    L = np.diag(off_diagonal, -1)
    D = np.diag(main_diagonal, 0)
    U = np.diag(off_diagonal, 1)

    E = D + L
    B = U

    A = L + D + U

    b = np.zeros(n)
    b[0] = 1
    b[-1] = 1

    x0 = np.zeros(n)
    n_iters = 0
    resid = 10 * tol

    while resid > tol:
        n_iters += 1
        x = np.linalg.solve(E, b - B @ x0)
        resid = np.linalg.norm(A @ x - b)
        x0 = x

    print("{} {} {:e}".format(n, n_iters, resid))
