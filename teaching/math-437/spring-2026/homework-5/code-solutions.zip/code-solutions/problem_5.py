import sympy as sp

A = sp.Matrix([[1, 2, -1], [0, 1, 2], [-1, 4, 3]])
print(A.inv())
