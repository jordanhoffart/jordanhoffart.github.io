"""
Solve A @ x = b with

A = [7 -1  1  1]
    [3  9  9  1]
    [3  3 15  1]
    [3  3  5 14]

b = [1 1 1 1]^T

using (a) Jacobi, (b) Gauß–Seidel, and (c) successive over-relaxation (SOR)
with omega = 1.0911. Report the residuals and the number of iterations. Here,
we follow numpy notation, where @ denotes matrix-vector multiplication.

Iterative methods write A in the form A = E + B and solve

E @ x_{n+1} + B @ x_n = b

with initial guess x_0. Here, we take x_0 = 0.

First, we let D be the diagonal of A and L be the strictly lower-triangular
part of A. Then, for

(a) Jacobi,      E := D,
(b) Gauß–Seidel, E := D + L,
(c) SOR,         E := D / omega + L.

To test if an iterative method is converging, we use the residual

r_{n+1} = norm(A @ x_{n+1} - b),

where norm(v) := sqrt(sum_i |v_i|^2) is the l_2 norm, which is the default used
by numpy.

(d) Find the spectral radius of the iteration matrix T := E^{-1} @ B for each
of the previous methods. We do this by finding the magnitude of the largest
eigenvalue of T.
"""

import numpy as np

A = np.array()  # fixme
b = np.array()  # fixme
omega = 0  # fixme

D = np.diag(np.diag())  # fixme
L = np.tril(0, k=0)  # fixme

E_jacobi = 0  # fixme
E_gs = 0  # fixme
E_sor = 0  # fixme

B_jacobi = 0  # fixme
B_gs = 0  # fixme
B_sor = 0  # fixme

x0_jacobi = np.zeros(4)
x0_gs = np.zeros(4)
x0_sor = np.zeros(4)

tol = 1e-5

n_jacobi = 0
n_gs = 0
n_sor = 0

resid_jacobi = 10 * tol
resid_gs = 10 * tol
resid_sor = 10 * tol

print("(a) Jacobi")
while resid_jacobi > tol:
    n_jacobi += 0  # fixme
    x_jacobi = np.linalg.solve(0, 0)  # fixme
    resid_jacobi = np.linalg.norm()  # fixme
    print("{:d} {:e}".format(n_jacobi, resid_jacobi))
    x0_jacobi = 0  # fixme
print()

print("(b) Gauß–Seidel")
while resid_gs > tol:
    n_gs += 0  # fixme
    x_gs = np.linalg.solve(0, 0)  # fixme
    resid_gs = np.linalg.norm()  # fixme
    print("{:d} {:e}".format(n_gs, resid_gs))
    x0_gs = 0  # fixme
print()

print("(c) SOR")
while resid_sor > tol:
    n_sor += 1
    x_sor = np.linalg.solve(0, 0)  # fixme
    resid_sor = np.linalg.norm()  # fixme
    print("{:d} {:e}".format(n_sor, resid_sor))
    x0_sor = 0  # fixme
print()

print("(d) Spectral radii")

T_jacobi = np.linalg.inv() @ 0  # fixme
T_gs = np.linalg.inv() @ 0  # fixme
T_sor = np.linalg.inv() @ 0  # fixme

eigenvalues_jacobi = np.linalg.eigvals()  # fixme
eigenvalues_gs = np.linalg.eigvals()  # fixme
eigenvalues_sor = np.linalg.eigvals()  # fixme

spectral_radius_jacobi = max([abs() for lam in 0])  # fixme
spectral_radius_gs = max([abs() for lam in 0])  # fixme
spectral_radius_sor = max([abs() for lam in 0])  # fixme

print("Jacobi:      {:e}".format(spectral_radius_jacobi))
print("Gauß–Seidel: {:e}".format(spectral_radius_gs))
print("SOR:         {:e}".format(spectral_radius_sor))
