"""
For n = 10, 20, 40, solve

A @ x = b,

where A is the n x n tridiagonal matrix with entries 2 on the diagonal and -1
on the off-diagonals, and b is the n-dimensional vector with first and last
entry 1 and all other entries 0.

Use the Gauß–Seidel iterative method

(D + L) @ x_{n+1} + U @ x_n = b,

where D is the diagonal of A, L is the strictly lower-triangular part of A, and
U is the strictly upper-triangular part of A. Using the notation from class,

E := D + L,
B := A - E = U,
E @ x_{n+1} + B @ x_n = b.

Start with initial guess x_0 = 0, solve to tolerance 10^{-5}, and report the
number of iterations and the final residual. To compute the final residual,

r_{n+1} = norm(A @ x_{n+1} - b),

where norm() is the l_2 norm, which is the default used by numpy, and x_{n+1}
is the solution at the last iteration.
"""

import numpy as np

ns = [10, 20, 40]
tol = 1e-5

print("n iters resid")
for n in ns:
    off_diagonal = np.ones()  # fixme
    main_diagonal = 0 * np.ones()  # fixme

    L = np.diag(0, 0)  # fixme
    D = np.diag(0, 0)  # fixme
    U = np.diag(0, 0)  # fixme

    E = 0  # fixme
    B = 0  # fixme

    A = 0 + 0 + 0  # fixme

    b = np.zeros(0)  # fixme
    b[0] = 0  # fixme
    b[-1] = 0  # fixme

    x0 = np.zeros(n)
    n_iters = 0
    resid = 10 * tol

    while resid > tol:
        n_iters += 0  # fixme
        x = np.linalg.solve(0, 0)  # fixme
        resid = np.linalg.norm(0)  # fixme
        x0 = 0  # fixme

    print("{} {} {:e}".format(n, n_iters, resid))
