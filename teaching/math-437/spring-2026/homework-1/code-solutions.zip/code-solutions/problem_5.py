from implementation import newton, print_results
from math import exp, log, cos, sin

x_0 = 1.5

f = lambda x: exp(x) + 2 ** (-x) + 2 * cos(x) - 6
df = lambda x: exp(x) - 2 ** (-x) * log(2) - 2 * sin(x)

tolerance = 1e-5
max_iterations = 100

results = newton(x_0, f, df, tolerance, max_iterations)
print_results(results)
