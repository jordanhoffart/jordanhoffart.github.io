from implementation import fixed_point, print_results

x_0 = 3.5
g = lambda x: 5 / x**2 + 2
tolerance = 1e-5
max_iterations = 100

results = fixed_point(x_0, g, tolerance, max_iterations)
print_results(results)
