from implementation import newton, print_results

x_0 = 3

g = lambda x: x**3 - 6
dg = lambda x: 3 * x**2
f = lambda x: x - g(x)
df = lambda x: 1 - dg(x)

tolerance = 0
max_iterations = 5

results = newton(x_0, f, df, tolerance, max_iterations)
print_results(results)
