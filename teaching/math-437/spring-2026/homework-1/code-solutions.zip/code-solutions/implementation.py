def fixed_point(x_0, g, tolerance, max_iterations):
    iterations = 1
    x = x_0
    residual = abs(x - g(x))

    xs = [x]
    residuals = [residual]

    while residual >= tolerance and iterations <= max_iterations:
        x = g(x)
        xs.append(x)
        residual = abs(x - g(x))
        residuals.append(residual)
        iterations += 1

    results = {"xs": xs, "residuals": residuals}
    return results


def newton(x_0, f, df, tolerance, max_iterations):
    iterations = 1
    x = x_0
    residual = abs(f(x))

    xs = [x]
    residuals = [residual]

    while residual >= tolerance and iterations <= max_iterations:
        x = x - f(x) / df(x)
        xs.append(x)
        residual = abs(f(x))
        residuals.append(residual)
        iterations += 1

    results = {"xs": xs, "residuals": residuals}
    return results


def print_results(results):
    xs = results["xs"]
    residuals = results["residuals"]
    print("iteration x residual")
    for i in range(len(xs)):
        print("{:2d} {:6e} {:6e}".format(i, xs[i], residuals[i]))
