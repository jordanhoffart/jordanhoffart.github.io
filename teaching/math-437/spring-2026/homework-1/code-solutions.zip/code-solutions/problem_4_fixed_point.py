from implementation import fixed_point, print_results

x_0 = 2.001
g = lambda x: x**3 - 6
tolerance = 0
max_iterations = 5

results = fixed_point(x_0, g, tolerance, max_iterations)
print_results(results)
