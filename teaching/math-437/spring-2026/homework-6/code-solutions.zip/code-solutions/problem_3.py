import numpy as np

A = np.array([[4, 2, 1], [2, 4, 0], [1, 0, 4]])

x = np.array([1, 1, 1])
p = 0
print("first coordinate")
for _ in range(3):
    y = A @ x
    mu = y[p] / x[p]
    print(mu, y)
    x = y

print()

x = np.array([1, 1, 1])
p = 1
print("second coordinate")
for _ in range(3):
    y = A @ x
    mu = y[p] / x[p]
    print(mu, y)
    x = y

print()

x = np.array([1, 1, 1])
p = 2
print("third coordinate")
for _ in range(3):
    y = A @ x
    mu = y[p] / x[p]
    print(mu, y)
    x = y
