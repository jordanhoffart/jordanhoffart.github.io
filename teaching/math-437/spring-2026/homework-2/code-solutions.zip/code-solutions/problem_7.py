from implementation import centered_difference, forward_difference
from math import exp

f = lambda x: exp(2 * x)
df = lambda x: 2 * exp(2 * x)
x = 1
hs = [0.1, 0.05]

methods = [
    {"name": "forward difference", "formula": forward_difference},
    {"name": "centered difference", "formula": centered_difference},
]

print("true value: f'(x) = {}".format(df(x)))
for method in methods:
    print()
    print(method["name"])
    for h in hs:
        print("h = {}".format(h), "f'(x) ~ {}".format(method["formula"](f, h, x)))
