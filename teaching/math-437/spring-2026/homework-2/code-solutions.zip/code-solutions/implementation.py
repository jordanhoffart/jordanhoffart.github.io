def lagrange_interpolant(xs, ys, x):
    n = len(xs)

    assert n > 0
    assert len(ys) == n

    p_x = 0

    for i in range(n):
        x_i = xs[i]
        y_i = ys[i]

        numerator = 1
        denominator = 1

        for j in range(i):
            x_j = xs[j]
            numerator *= x - x_j
            denominator *= x_i - x_j

        for j in range(i + 1, n):
            x_j = xs[j]
            numerator *= x - x_j
            denominator *= x_i - x_j

        p_x += y_i * numerator / denominator

    return p_x


def centered_difference(f, h, x):
    return (f(x + h) - f(x - h)) / (2 * h)


def forward_difference(f, h, x):
    return (f(x + h) - f(x)) / h
