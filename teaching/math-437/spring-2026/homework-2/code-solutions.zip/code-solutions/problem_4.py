from implementation import lagrange_interpolant

xs = [0.1, 0.2, 0.3, 0.5, 0.6, 0.7]
ys = [-7, -5, -2, 1, 3, 9]
x = 0.4

print("f({}) = {}".format(x, lagrange_interpolant(xs, ys, 0.4)))
