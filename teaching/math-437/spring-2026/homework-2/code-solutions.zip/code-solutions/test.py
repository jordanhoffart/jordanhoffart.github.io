from implementation import lagrange_interpolant

n = 10
p = lambda x: x**n

xs = [i / n for i in range(n + 1)]
ys = [p(x) for x in xs]

e = sum([abs(lagrange_interpolant(xs, ys, x) - p(x)) for x in xs])

if e < 1e-16:
    print("test passed, e =", e)
else:
    print("test failed, e =", e)
