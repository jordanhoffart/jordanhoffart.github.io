from math import exp, log

tol = 1e-12
max_iter = 100

F = lambda y_m, h, y: y_m + h * exp(y_m) - y
dF = lambda y_m, h: 1 + h * exp(y_m)
residual = lambda y_m, h, y: abs(F(y_m, h, y))

y_exact = lambda t: -log(t + 1)

for h in [0.2, 0.1]:
    t = 0
    y = 0

    while t < 2:
        t = t + h

        m = 0
        y_m = y
        while residual(y_m, h, y) > tol and m < max_iter:
            y_m = y_m - F(y_m, h, y) / dF(y_m, h)
            m = m + 1
        y = y_m

    y_ex = y_exact(t)
    error = abs(y_ex - y)
    print("h = {}, error = {}".format(h, error))
