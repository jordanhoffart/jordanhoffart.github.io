from math import exp

f = lambda y: exp(-100 * y)
y_0 = 1
hs = [0.01, 0.001]
N = 3

for h in hs:
    y_fe = y_0
    y_be = y_0
    for n in range(1, N + 1):
        y_fe = y_fe * (1 - 100 * h)
        y_be = y_be / (1 + 100 * h)

    y_exact = f(N * h)
    error_fe = abs(y_exact - y_fe)
    error_be = abs(y_exact - y_be)

    print("h = {}".format(h))
    print("exact: {}".format(y_exact))
    print("explicit Euler (error): {} ({})".format(y_fe, error_fe))
    print("implicit Euler (error): {} ({})".format(y_be, error_be))
    print()
