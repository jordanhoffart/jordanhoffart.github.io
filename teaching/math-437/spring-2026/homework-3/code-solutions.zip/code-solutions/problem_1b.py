from math import exp

f = lambda x: x**2 * exp(-(x**2))
a = 0
bs = [1, 2]
hs = [0.1, 0.05]

for b in bs:
    print("integrating on [{}, {}]".format(a, b))
    for h in hs:
        n = int((b - a) / h)
        integral = 0
        for i in range(1, n + 1):
            x = a + i * h
            integral = integral + f(x)
        integral = integral * h
        print("h = {}, integral = {}".format(h, integral))
