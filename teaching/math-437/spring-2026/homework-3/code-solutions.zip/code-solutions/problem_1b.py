from math import exp

f = lambda x: x**2 * exp(-(x**2))
a = 0
b = 1
hs = [0.1, 0.05]

for h in hs:
    n = int((b - a) / h)
    integral = 0
    for i in range(1, n + 1):
        x = a + i * h
        integral = integral + f(x)
    integral = integral * h
    print("h = {}, integral = {}".format(h, integral))
