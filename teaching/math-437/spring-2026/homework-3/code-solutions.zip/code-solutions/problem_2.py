from math import exp, sin

f = lambda x: exp(2 * x) * sin(3 * x)
a = 0
b = 2
hs = [0.1, 0.05]

for h in hs:
    n = int((b - a) / h)
    integral = f(a) + f(b)
    for i in range(1, n):
        x = a + i * h
        integral = integral + 2 * f(x)
    integral = integral * h / 2
    print("{} {}".format(h, integral))
