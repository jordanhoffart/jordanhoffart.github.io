from math import sqrt

t_0 = 1
y_0 = 2
h = 0.02
f = lambda t, y: (1 + t) / (1 + y)
y_exact = lambda t: sqrt(t**2 + 2 * t + 6) - 1

y_fe = y_0
y_rk4 = y_0
t = t_0

while t < 2:
    y_fe = y_fe + h * f(t, y_fe)

    k1 = f(t, y_rk4)
    k2 = f(t + h / 2, y_rk4 + h * k1 / 2)
    k3 = f(t + h / 2, y_rk4 + h * k2 / 2)
    k4 = f(t + h, y_rk4 + h * k3)
    y_rk4 = y_rk4 + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

    t = t + h

y_ex = y_exact(t)
error_fe = abs(y_ex - y_fe)
error_rk4 = abs(y_ex - y_rk4)
print("explicit Euler error = {}".format(error_fe))
print("RK4 error = {}".format(error_rk4))
