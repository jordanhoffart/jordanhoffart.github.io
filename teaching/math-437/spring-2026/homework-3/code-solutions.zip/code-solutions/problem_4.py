import sympy as sp

a, b, c, d = sp.symbols("a b c d")

solutions = sp.linsolve(
    [
        a + b + c + d - 2,
        -a + b + c + d,
        a + b - 2 * c + 2 * d - sp.Rational(2, 3),
        -a + b + 3 * c + 3 * d,
    ],
    (a, b, c, d),
)

print(solutions)
