from math import exp, sqrt

f = lambda x: x**2 * exp(-x)
a = 0
b = 1

x_hats = [-1 / sqrt(3), 1 / sqrt(3)]
w_hats = [1, 1]

integral = 0
for i in range(len(x_hats)):
    x = (a + b) / 2 + (b - a) / 2 * x_hats[i]
    w = (b - a) / 2 * w_hats[i]
    integral = integral + w * f(x)

print(integral)
