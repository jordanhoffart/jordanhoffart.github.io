from math import exp, sqrt

f = lambda x: x**2 * exp(-x)
a = 0
b = 1

x_hats = {2: [-1 / sqrt(3), 1 / sqrt(3)], 3: [-sqrt(3 / 5), 0, sqrt(3 / 5)]}
w_hats = {2: [1, 1], 3: [5 / 9, 8 / 9, 5 / 9]}

for n in [2, 3]:
    integral = 0
    for i in range(n):
        x = (a + b) / 2 + (b - a) / 2 * x_hats[n][i]
        w = (b - a) / 2 * w_hats[n][i]
        integral = integral + w * f(x)
    print("n = {} points, integral = {}".format(n, integral))
