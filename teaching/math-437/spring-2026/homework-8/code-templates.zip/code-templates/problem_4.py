import numpy as np


# function to solve F(x) = 0
def F(x):
    # components of x
    x_1 = 0  # fixme
    x_2 = 0  # fixme

    # components of F
    F_1 = 0  # fixme
    F_2 = 0  # fixme

    return np.array([F_1, F_2])


# F(0)
F0 = 0  # fixme


# Jacobian matrix of F
def DF(x):
    # components of x
    x_1 = 0  # fixme
    x_2 = 0  # fixme

    # components of the Jacobian
    DF_11 = 0  # fixme
    DF_12 = 0  # fixme
    DF_21 = 0  # fixme
    DF_22 = 0  # fixme

    return np.array([[DF_11, DF_12], [DF_21, DF_22]])


# initial condition
x0 = np.array([_, _])  # fixme

# timestep
tau = 0  # fixme

for n in range(1, 6):
    # update
    x = 0  # fixme
    print(n, x)

    # prepare for next iteration
    x0 = 0  # fixme
