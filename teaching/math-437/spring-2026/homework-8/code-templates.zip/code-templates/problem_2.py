import numpy as np
from scipy.integrate import quad

# discrete mesh points
x_0 = 0
x_1 = 0  # fixme
x_2 = 0  # fixme
x_3 = 0  # fixme

# meshsize
h = 0  # fixme


# first basis function at x_1
def phi_1(x):
    if x < x_0 or x > x_2:
        return 0
    if x <= x_1:
        return 0  # fixme
    return 0  # fixme


# derivative of phi_1
def dphi_1(x):
    if x < x_0 or x > x_2:
        return 0
    if x <= x_1:
        return 0  # fixme
    return 0  # fixme


# second basis function at x_2
def phi_2(x):
    if x < 0 or x > 0:  # fixme
        return 0
    if x <= 0:  # fixme
        return 0  # fixme
    return 0  # fixme


# derivative of phi_2
def dphi_2(x):
    if x < 0 or x > 0:  # fixme
        return 0
    if x <= 0:  # fixme
        return 0  # fixme
    return 0  # fixme


# Use quad from scipy.integrate to compute the entries A_{i,j} and b_i.
# I'm not sure if quad handles integrating discontinuous functions, so it's
# best to split each integral over [0,1] into a sum of integrals over each
# subinterval [x_j, x_{j+1}] where the phi_j are continuous. For example:

A_11 = quad(lambda x: 0, x_0, x_1)[0] + quad(lambda x: 0, x_1, x_2)[0]  # fixme

A_12 = quad(lambda x: 0, 0, 0)[0]  # fixme
A_21 = quad(lambda x: 0, 0, 0)[0]  # fixme

A_22 = quad(lambda x: 0, 0, 0)[0] + quad(lambda x: 0, 0, 0)[0]  # fixme

b_1 = quad(lambda x: 0, 0, 0)[0] + quad(lambda x: 0, 0, 0)[0]  # fixme

b_2 = quad(lambda x: 0, 0, 0)[0] + quad(lambda x: 0, 0, 0)[0]  # fixme

A = np.array([[A_11, A_12], [A_21, A_22]])
b = np.array([b_1, b_2])
y = np.linalg.solve(A, b)

print("A =")
print(A)

print()

print("b =")
print(b)

print()

print("x_j y_j")
print(x_1, y[0])
print(x_2, y[1])
