import numpy as np

# mesh size
h = 0  # fixme


# function F(y) for Newton's method
def F(y):
    # 2 components of y
    y_1 = 0  # fixme
    y_2 = 0  # fixme

    # 2 components of F
    F_1 = 0  # fixme
    F_2 = 0  # fixme

    return np.array([F_1, F_2])


# Jacobian matrix of F
def DF(y):
    # 2 components of y
    y_1 = 0  # fixme
    y_2 = 0  # fixme

    # components of the Jacobian
    DF_11 = 0  # fixme
    DF_12 = 0  # fixme
    DF_21 = 0  # fixme
    DF_22 = 0  # fixme

    return np.array([[DF_11, DF_12], [DF_21, DF_22]])


# Newton iterations
y0 = np.array([_, _])  # fixme
y1 = y0  # fixme
y2 = y1  # fixme

print("y1 =")
print(y1)
print()

print("y2 =")
print(y2)
