import matplotlib.pyplot as plt

# final time
T = 0  # fixme

# timestep
tau = 0  # fixme

# number of timesteps
N = int(T / tau)

# spatial mesh size
h = 0  # fixme

# number of spatial grid points
M = int(1 / h)

# discrete spatial points
xs = [0 for i in range(M + 1)]  # fixme

# solution at time t_n
old_us = [_ for _ in range(M + 1)]  # fixme

# solution at time t_{n+1}
new_us = [_ for _ in range(M + 1)]  # fixme

# loop to final time
for _ in range(N):
    for i in range(1, len(xs) - 1):
        # u(x_i, t_{n+1})
        new_us[i] = 0  # fixme

    # apply boundary conditions
    new_us[0] = _  # fixme
    new_us[-1] = _  # fixme

    # prepare for next timestep
    for i in range(len(xs)):
        old_us[i] = 0  # fixme

# produce plot at final time, save as problem_1.png
plt.plot(xs, new_us)
plt.xlabel("x")
plt.ylabel("u(T,x)")
plt.title("u(T,x) vs x for T = 0.1")
plt.savefig("problem_1.png")
plt.show()
