import numpy as np

h = 1 / 3


def F(y):
    y_1 = y[0]
    y_2 = y[1]

    F_1 = (y_2 - 2 * y_1) / h**2 + 2 * y_1**3 - 1
    F_2 = (y_1 - 2 * y_2) / h**2 + 2 * y_2**3 - 1

    return np.array([F_1, F_2])


def DF(y):
    y_1 = y[0]
    y_2 = y[1]

    DF_11 = -2 / h**2 + 6 * y_1**2
    DF_12 = 1 / h**2
    DF_21 = 1 / h**2
    DF_22 = -2 / h**2 + 6 * y_2**2

    return np.array([[DF_11, DF_12], [DF_21, DF_22]])


y0 = np.array([0, 0])
y1 = y0 - np.linalg.inv(DF(y0)) @ F(y0)
y2 = y1 - np.linalg.inv(DF(y1)) @ F(y1)

print("y1 =")
print(y1)
print()

print("y2 =")
print(y2)
