import numpy as np


def F(x):
    x_1 = x[0]
    x_2 = x[1]

    F_1 = x_1 + x_2**2 - 6
    F_2 = -x_1 + x_2 - 1

    return np.array([F_1, F_2])


F0 = F([0, 0])


def DF(x):
    x_2 = x[1]

    DF_11 = 1
    DF_12 = 2 * x_2
    DF_21 = -1
    DF_22 = 1

    return np.array([[DF_11, DF_12], [DF_21, DF_22]])


x0 = np.array([0, 0])

tau = 0.2

for n in range(1, 6):
    x = x0 - tau * np.linalg.inv(DF(x0)) @ F0
    print(n, x)
    x0 = x
