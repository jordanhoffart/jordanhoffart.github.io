import numpy as np
from scipy.integrate import quad

x_0 = 0
x_1 = 1 / 3
x_2 = 2 / 3
x_3 = 1

h = 1 / 3


def phi_1(x):
    if x < x_0 or x > x_2:
        return 0
    if x <= x_1:
        return (x - x_0) / h
    return (x_2 - x) / h


def dphi_1(x):
    if x < x_0 or x > x_2:
        return 0
    if x <= x_1:
        return 1 / h
    return -1 / h


def phi_2(x):
    if x < x_1 or x > x_3:
        return 0
    if x <= x_2:
        return (x - x_1) / h
    return (x_3 - x) / h


def dphi_2(x):
    if x < x_1 or x > x_3:
        return 0
    if x <= x_2:
        return 1 / h
    return -1 / h


A_11 = (
    quad(lambda x: dphi_1(x) * dphi_1(x) + phi_1(x) * phi_1(x), x_0, x_1)[0]
    + quad(lambda x: dphi_1(x) * dphi_1(x) + phi_1(x) * phi_1(x), x_1, x_2)[0]
)

A_12 = quad(lambda x: dphi_2(x) * dphi_1(x) + phi_2(x) * phi_1(x), x_1, x_2)[0]
A_21 = quad(lambda x: dphi_1(x) * dphi_2(x) + phi_1(x) * phi_2(x), x_1, x_2)[0]

A_22 = (
    quad(lambda x: dphi_2(x) * dphi_2(x) + phi_2(x) * phi_2(x), x_1, x_2)[0]
    + quad(lambda x: dphi_2(x) * dphi_2(x) + phi_2(x) * phi_2(x), x_2, x_3)[0]
)

b_1 = (
    quad(lambda x: x * phi_1(x), x_0, x_1)[0]
    + quad(lambda x: x * phi_1(x), x_1, x_2)[0]
)

b_2 = (
    quad(lambda x: x * phi_2(x), x_1, x_2)[0]
    + quad(lambda x: x * phi_2(x), x_2, x_3)[0]
)

A = np.array([[A_11, A_12], [A_21, A_22]])
b = np.array([b_1, b_2])
y = np.linalg.solve(A, b)

print("A =")
print(A)

print()

print("b =")
print(b)

print()

print("x_j y_j")
print(x_1, y[0])
print(x_2, y[1])
