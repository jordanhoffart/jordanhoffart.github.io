import matplotlib.pyplot as plt

T = 0.1
tau = 0.01
N = int(T / tau)

h = 0.1
M = int(1 / h)

xs = [i * h for i in range(M + 1)]
old_us = [0.0 for _ in range(M + 1)]
new_us = [0.0 for _ in range(M + 1)]

for _ in range(N):
    for i in range(1, len(xs) - 1):
        dx2u = (old_us[i + 1] - 2.0 * old_us[i] + old_us[i - 1]) / h**2
        new_us[i] = old_us[i] + tau * (xs[i] ** 2 + 0.5 * dx2u)
    new_us[0] = 0.0
    new_us[-1] = 0.0
    for i in range(len(xs)):
        old_us[i] = new_us[i]

plt.plot(xs, new_us)
plt.xlabel("x")
plt.ylabel("u(T,x)")
plt.title("u(T,x) vs x for T = 0.1")
plt.savefig("problem_1.png")
plt.show()
